library(venn)
library(ggplot2)
library(lattice)
library(reshape)
library(epiR)
library(data.table)
library(ggExtra)
library(scales)
library(Gviz)
library(stats)
library(data.table)
library(adegenet)


setwd("/media/sf_Shared_genomic/Covid_19_version_may_1/Aligment_June/Final/Submission_data/R_analysis")
load(file="Data_sars_cov_2_evolution.RData", verbose = T)


#######################################################################################################################################
#######################################################################################################################################

#covid19_mature_products = read.delim("mature_prod.bed", header=F)
head(covid19_mature_products)
dim(covid19_mature_products)
covid19_mature_products <- covid19_mature_products[-7,] 
covid19_mature_products

#covid19_mature_products_2 <- data.frame( chrom = "chr", start= covid19_mature_products$V2, end = covid19_mature_products$V3, gene = covid19_mature_products$V4)
head(covid19_mature_products_2)
dim(covid19_mature_products_2)
summary(covid19_mature_products_2)



#covid19_data_ref = read.table("sars2.selection.data", header = TRUE) 
head(covid19_data_ref)
colnames(covid19_data_ref)
summary(covid19_data_ref)
dim(covid19_data_ref)




#covid19_data_ref2 = read.csv("sars2.selection.csv", header = TRUE) 
head(covid19_data_ref2)
tail(covid19_data_ref2)
summary(covid19_data_ref2)
dim(covid19_data_ref2)

covid19_data_ref3 <- data.frame(chr = covid19_data_ref2$chr, 
                                start = covid19_data_ref2$start, 
                                end = covid19_data_ref2$end, 
                                replicate= covid19_data_ref2$replicate, 
                                ref = covid19_data_ref2$RsubsRate.SARS_CoV_2,
                                query = covid19_data_ref2$QsubsRate.SARS_CoV_2)
covid19_data_wide_ref <- reshape(covid19_data_ref3, idvar = c('chr', 'start', 'end'), timevar = "replicate", direction = "wide")

head(covid19_data_wide_ref)


head(covid19_data_ref2)

covid19_data_pval <- data.frame(chr = covid19_data_ref2$chr, 
                                start = covid19_data_ref2$start, 
                                end = covid19_data_ref2$end, 
                                replicate= covid19_data_ref2$replicate, 
                                pval = (covid19_data_ref2$pval.SARS_CoV_2))
head(covid19_data_pval)

covid19_data_ref_melt <- melt(covid19_data_ref, id.vars = c("genome_location", "replicate"))
head(covid19_data_ref_melt)

covid19_data_ref_melt_cast <- dcast(covid19_data_ref_melt, genome_location ~ variable, fun.aggregate = mean, na.rm = T)
head(covid19_data_ref_melt_cast)
dim(covid19_data_ref_melt_cast)
summary(covid19_data_ref_melt_cast)

head(covid19_data_ref2)
#dim(covid19_data_ref2)
#colnames(covid19_data_ref2)

#padj.SARS_CoV_2 <- data.frame(chr = as.character(),start = as.numeric(), end = as.numeric(),  replicate = as.numeric(),  pval = as.numeric(), padj.SARS_CoV_2 = as.numeric())
#padj.SARS_CoV_2
#for ( location in 1:length(covid19_data_ref_melt_cast[,1]) ) {
 # n=0
#  #print(as.character(covid19_data_ref_melt_cast[location,1]))
 # padj <- data.frame(gene_location = as.character(), replicate = as.numeric(), pval = as.numeric())
  
#  for ( replicates in 1:length(covid19_data_ref2[,1]) ){
#    row <- paste(paste(covid19_data_ref2[replicates,1], covid19_data_ref2[replicates,2], sep=":"), covid19_data_ref2[replicates,3], sep ="-")
#    if (  row == as.character(covid19_data_ref_melt_cast[location,1])  ) {
#      n = n + 1
#      #print(n)
#      if (covid19_data_ref2[replicates,4] == n - 1 ) {
#        #print(replicates)
#        pavalue <- data.frame( chr = as.character( covid19_data_ref2[replicates,1] ), start = as.numeric( covid19_data_ref2[replicates,2] ),end = as.numeric( covid19_data_ref2[replicates,3] ),replicate = n - 1,  pval = covid19_data_ref2[replicates,28] )
#        padj <- rbind(padj, pavalue)
#        
#      }
#      #print(dim(padj))
#    }
#    
#    
#    
#  }
  #print(mean(p.adjust(padj[,2], "fdr")))
#  new_table <- data.frame( chr = padj[,1], start = padj[,2], end = padj[,3], replicate = padj[,4] ,  padj.SARS_CoV_2 = (p.adjust(padj[,5], "fdr")))
#  padj.SARS_CoV_2 <- rbind(padj.SARS_CoV_2, new_table)
#}
head(covid19_data_ref2[,28])
head(covid19_data_ref2)

dim(padj.SARS_CoV_2)
colnames(covid19_data_ref2)

#padj.SARS_CoV <- data.frame(chr = as.character(),start = as.numeric(), end = as.numeric(),  replicate = as.numeric(),  pval = as.numeric(), padj.SARS_CoV = as.numeric())
#padj.SARS_CoV
#for ( location in 1:length(covid19_data_ref_melt_cast[,1]) ) {
#  n=0
#  #print(as.character(covid19_data_ref_melt_cast[location,1]))
#  padj <- data.frame(gene_location = as.character(), replicate = as.numeric(), pval = as.numeric())
#  
#  for ( replicates in 1:length(covid19_data_ref2[,1]) ){
#    row <- paste(paste(covid19_data_ref2[replicates,1], covid19_data_ref2[replicates,2], sep=":"), covid19_data_ref2[replicates,3], sep ="-")
#    if (  row == as.character(covid19_data_ref_melt_cast[location,1])  ) {
#      n = n + 1
#      #print(n)
#      if (covid19_data_ref2[replicates,4] == n - 1 ) {
#        #print(replicates)
#        pavalue <- data.frame( chr = as.character( covid19_data_ref2[replicates,1] ), start = as.numeric( covid19_data_ref2[replicates,2] ),end = as.numeric( covid19_data_ref2[replicates,3] ),replicate = n - 1,  pval = covid19_data_ref2[replicates,24] )
#        padj <- rbind(padj, pavalue)
#        
#      }
#      #print(dim(padj))
#    }
#    
#    
#    
#  }
#  #print(mean(p.adjust(padj[,2], "fdr")))
#  new_table <- data.frame( chr = padj[,1], start = padj[,2], end = padj[,3], replicate = padj[,4] ,  padj.SARS_CoV = (p.adjust(padj[,5], "fdr")))
#  padj.SARS_CoV <- rbind(padj.SARS_CoV, new_table)
#}
head(covid19_data_ref2[,24])
head(padj.SARS_CoV)
head(padj.SARS_CoV_2)

dim(padj.SARS_CoV)


head(covid19_data_ref_melt_cast)

colnames(covid19_data_ref_melt_cast)

#padj.RatG13 <- data.frame(chr = as.character(),start = as.numeric(), end = as.numeric(),  replicate = as.numeric(),  pval = as.numeric(), padj.RatG13 = as.numeric())
#padj.RatG13
#for ( location in 1:length(covid19_data_ref_melt_cast[,1]) ) {
#  n=0
#  #print(as.character(covid19_data_ref_melt_cast[location,1]))
#  padj <- data.frame(gene_location = as.character(), replicate = as.numeric(), pval = as.numeric())
#  
#  for ( replicates in 1:length(covid19_data_ref2[,1]) ){
#    row <- paste(paste(covid19_data_ref2[replicates,1], covid19_data_ref2[replicates,2], sep=":"), covid19_data_ref2[replicates,3], sep ="-")
#    if (  row == as.character(covid19_data_ref_melt_cast[location,1])  ) {
#      n = n + 1
#      #print(n)
 #     if (covid19_data_ref2[replicates,4] == n - 1 ) {
#        #print(replicates)
#        pavalue <- data.frame( chr = as.character( covid19_data_ref2[replicates,1] ), start = as.numeric( covid19_data_ref2[replicates,2] ),end = as.numeric( covid19_data_ref2[replicates,3] ),replicate = n - 1,  pval = covid19_data_ref2[replicates,12] )
#        padj <- rbind(padj, pavalue)
#        
#      }
#      #print(dim(padj))
#    }
#    
#    
#    
#  }
#  #print(mean(p.adjust(padj[,2], "fdr")))
#  new_table <- data.frame( chr = padj[,1], start = padj[,2], end = padj[,3], replicate = padj[,4] ,  padj.RatG13 = (p.adjust(padj[,5], "fdr")))
#  padj.RatG13 <- rbind(padj.RatG13, new_table)
#}
head(covid19_data_ref2)
colnames(covid19_data_ref2)

head(covid19_data_ref2[,12])
head(padj.RatG13)
dim(padj.RatG13)


head(covid19_data_ref2)
colnames(covid19_data_ref2)

#padj.Pa_CoV_Guangxi_P4L <- data.frame(chr = as.character(),start = as.numeric(), end = as.numeric(),  replicate = as.numeric(),  pval = as.numeric(), padj.Pa_CoV_Guangxi_P4L = as.numeric())
#padj.Pa_CoV_Guangxi_P4L
#for ( location in 1:length(covid19_data_ref_melt_cast[,1]) ) {
#  n=0
#  #print(as.character(covid19_data_ref_melt_cast[location,1]))
 # padj <- data.frame(gene_location = as.character(), replicate = as.numeric(), pval = as.numeric())
  
#  for ( replicates in 1:length(covid19_data_ref2[,1]) ){
#    row <- paste(paste(covid19_data_ref2[replicates,1], covid19_data_ref2[replicates,2], sep=":"), covid19_data_ref2[replicates,3], sep ="-")
#    if (  row == as.character(covid19_data_ref_melt_cast[location,1])  ) {
#      n = n + 1
#      #print(n)
#      if (covid19_data_ref2[replicates,4] == n - 1 ) {
#        #print(replicates)
#        pavalue <- data.frame( chr = as.character( covid19_data_ref2[replicates,1] ), start = as.numeric( covid19_data_ref2[replicates,2] ),end = as.numeric( covid19_data_ref2[replicates,3] ),replicate = n - 1,  pval = covid19_data_ref2[replicates,20] )
#        padj <- rbind(padj, pavalue)
#        
#      }
#      #print(dim(padj))
#    }
#    
#    
#    
#  }
#  #print(mean(p.adjust(padj[,2], "fdr")))
#  new_table <- data.frame( chr = padj[,1], start = padj[,2], end = padj[,3], replicate = padj[,4] ,  padj.Pa_CoV_Guangxi_P4L = (p.adjust(padj[,5], "fdr")))
#  padj.Pa_CoV_Guangxi_P4L <- rbind(padj.Pa_CoV_Guangxi_P4L, new_table)
#}
head(covid19_data_ref2)
head(padj.Pa_CoV_Guangxi_P4L)



#padj.Pa_CoV_Guangdong <- data.frame(chr = as.character(),start = as.numeric(), end = as.numeric(),  replicate = as.numeric(),  pval = as.numeric(), padj.Pa_CoV_Guangdong = as.numeric())
#padj.Pa_CoV_Guangdong
#for ( location in 1:length(covid19_data_ref_melt_cast[,1]) ) {
#  n=0
#  #print(as.character(covid19_data_ref_melt_cast[location,1]))
#  padj <- data.frame(gene_location = as.character(), replicate = as.numeric(), pval = as.numeric())
#  
#  for ( replicates in 1:length(covid19_data_ref2[,1]) ){
#    row <- paste(paste(covid19_data_ref2[replicates,1], covid19_data_ref2[replicates,2], sep=":"), covid19_data_ref2[replicates,3], sep ="-")
#    if (  row == as.character(covid19_data_ref_melt_cast[location,1])  ) {
#      n = n + 1
#      #print(n)
#      if (covid19_data_ref2[replicates,4] == n - 1 ) {
#        #print(replicates)
#        pavalue <- data.frame( chr = as.character( covid19_data_ref2[replicates,1] ), start = as.numeric( covid19_data_ref2[replicates,2] ),end = as.numeric( covid19_data_ref2[replicates,3] ),replicate = n - 1,  pval = covid19_data_ref2[replicates,16] )
#        padj <- rbind(padj, pavalue)
#        
#      }
#      #print(dim(padj))
#    }
#    
#    
#    
#  }
#  #print(mean(p.adjust(padj[,2], "fdr")))
#  new_table <- data.frame( chr = padj[,1], start = padj[,2], end = padj[,3], replicate = padj[,4] ,  padj.Pa_CoV_Guangdong = (p.adjust(padj[,5], "fdr")))
#  padj.Pa_CoV_Guangdong <- rbind(padj.Pa_CoV_Guangdong, new_table)
#}
head(covid19_data_ref2)
head(padj.Pa_CoV_Guangdong)






#padj.LYRa11 <- data.frame(chr = as.character(),start = as.numeric(), end = as.numeric(),  replicate = as.numeric(),  pval = as.numeric(), padj.LYRa11 = as.numeric())
#padj.LYRa11
#for ( location in 1:length(covid19_data_ref_melt_cast[,1]) ) {
#  n=0
#  #print(as.character(covid19_data_ref_melt_cast[location,1]))
#  padj <- data.frame(gene_location = as.character(), replicate = as.numeric(), pval = as.numeric())
#  
#  for ( replicates in 1:length(covid19_data_ref2[,1]) ){
#    row <- paste(paste(covid19_data_ref2[replicates,1], covid19_data_ref2[replicates,2], sep=":"), covid19_data_ref2[replicates,3], sep ="-")
#    if (  row == as.character(covid19_data_ref_melt_cast[location,1])  ) {
#      n = n + 1
#      #print(n)
#      if (covid19_data_ref2[replicates,4] == n - 1 ) {
#        print(replicates)
#        pavalue <- data.frame( chr = as.character( covid19_data_ref2[replicates,1] ), start = as.numeric( covid19_data_ref2[replicates,2] ),end = as.numeric( covid19_data_ref2[replicates,3] ),replicate = n - 1,  pval = covid19_data_ref2[replicates,8] )
#        padj <- rbind(padj, pavalue)
#        
#      }
#      print((padj))
#    }
#    
#    
#    
#  }
  #print(mean(p.adjust(padj[,2], "fdr")))
#  new_table <- data.frame( chr = padj[,1], start = padj[,2], end = padj[,3], replicate = padj[,4] ,  padj.LYRa11 = (p.adjust(padj[,5], "fdr")))
#  padj.LYRa11 <- rbind(padj.LYRa11, new_table)
#}
head(covid19_data_ref2)
head(padj.LYRa11)





padjusted <- data.frame( genome_location= paste(paste(padj.SARS_CoV_2[,1], padj.SARS_CoV_2[,2], sep = ":"), padj.SARS_CoV_2[,3], sep = "-"), 
                         replicate= padj.SARS_CoV_2[,4], 
                         padj.SARS_CoV_2 = padj.SARS_CoV_2[,5], 
                         padj.RatG13 =padj.RatG13[,5], 
                         padj.Pa_CoV_Guangdong= padj.Pa_CoV_Guangdong[,5], 
                         padj.Pa_CoV_Guangxi_P4L= padj.Pa_CoV_Guangxi_P4L[,5], 
                         padj.LYRa11 = padj.LYRa11[,5],
                         padj.SARS_CoV = padj.SARS_CoV[,5])


padjusted_melt <- melt(padjusted, id.vars = c("genome_location", "replicate"))
head(padjusted_melt)



covid19_data_padj <- data.frame(chr = padj.SARS_CoV_2$chr, 
                                start = padj.SARS_CoV_2$start, 
                                end = padj.SARS_CoV_2$end, 
                                replicate= padj.SARS_CoV_2$replicate, 
                                padj = -log10(padj.SARS_CoV_2$padj.SARS_CoV_2))

covid19_data_wide_padj <- reshape(covid19_data_padj, idvar = c('chr', 'start', 'end'), timevar = "replicate", direction = "wide")
head(covid19_data_wide_padj)

padj_track <- DataTrack(covid19_data_wide_padj, name = "-log10(P_adj)",   genome = 'wuhCor1',
                        #name = "RefSR", 
                        chromosome = 'chr',  groups = rep(c("padj.SARS_CoV_2"), 10),
                        type = c("p"),
                        size=10, 
                        col = c("black"), 
                        varwidth = T,legend = T, ylim= c(0,20),
                        lty.baseline= 1,baseline=1.3, col.baseline = "red",
                        fontcolor.feature = 1, col.border.title='white', background.panel='white',
                        background.title = 'white', col.axis='black',lwd=1, just.group = "left",
                        col.title="black", frame=FALSE, grid=FALSE)






padjusted_melt_cast <- dcast(padjusted_melt, genome_location ~ variable, fun.aggregate = mean, na.rm = T)
head(padjusted_melt_cast)
dim(padjusted_melt_cast)
summary(padjusted_melt_cast)



head(covid19_data_ref_melt_cast)
head(padjusted_melt_cast)

dim(covid19_data_ref_melt_cast)
dim(padjusted_melt_cast)

covid19_data <- (merge(covid19_data_ref_melt_cast,padjusted_melt_cast, by = "genome_location" ))
head(covid19_data)
dim(covid19_data)

filtered <- subset(covid19_data) # Human Gains
dim(filtered)
colnames(filtered)

p=0.05

filtered1 <- (subset(filtered,  padj.SARS_CoV_2 < p))
filtered2 <- (subset(filtered,  padj.SARS_CoV_2 < p &    padj.SARS_CoV < p ))
filtered3 <- (subset(filtered,  padj.SARS_CoV_2 < p  &   padj.SARS_CoV > p ))
filtered4 <- (subset(filtered,  padj.SARS_CoV_2 > p  &   padj.SARS_CoV < p ))



###############################################
##### 





###############################################
##### 
setwd("/media/sf_Shared_genomic/Covid_19_version_may_1/Aligment_June/Final/Submission_data/R_analysis")
covid19_substitutions3 = read.delim("5000_SARS_CoV_2_samples.bed", header=F, na.strings = "NA")

site_fre_spectrum = read.delim("Site_frequency_Spectrm_table.tab", header=T, na.strings = "NA")

head(site_fre_spectrum)

h<-hist(site_fre_spectrum$frequency, breaks=50, plot=F)
h$counts <- h$counts / sum(h$counts)
plot(h, freq=TRUE, ylab="Relative Frequency", xlab="Alternative Allele Frequency", col=rgb(0,0,0,1/4), ylim=c(0,0.6))
h2<-hist(subset(site_fre_spectrum, effect == "Synonimous")$frequency, breaks=50, plot=F)
h2$counts <- h2$counts / sum(h2$counts)
lines(h2, col=rgb(0,0,1,1/4))



h<-hist(site_fre_spectrum$frequency, breaks=25, plot=F)
h$counts <- h$counts / sum(h$counts)
plot(h, freq=TRUE, ylab="Relative Frequency", xlab="Alternative Allele Frequency", col=rgb(0,0,0,1/4), ylim=c(0,0.9))
  h2<-hist(subset(site_fre_spectrum, effect == "Synonimous")$frequency, breaks=25, plot=F)
h2$counts <- h2$counts / sum(h2$counts)
lines(h2, col=rgb(0,0,1,1/4))



head(covid19_substitutions3)
dim(covid19_substitutions3)

summary(covid19_substitutions3)
substitutions3 <- data.frame( chr = covid19_substitutions3$V1,  
                             start = covid19_substitutions3$V2, 
                             end = covid19_substitutions3$V3, 
                             value = covid19_substitutions3$V4)

head(substitutions3)
dim(substitutions3)


setwd("/media/sf_Shared_genomic/Covid_19_version_may_1/Aligment_June/Final/Submission_data/R_analysis")
write.table(substitutions3, file ="substitutions3.bedGraph", row.names=F, col.names=F, quote=F,sep='\t') 



substitutions3 <- fread(
  './substitutions3.bedGraph',header=F,
  col.names = c('chromosome', 'start', 'end', 'value')
)
substitutions3 <- substitutions3[order(start)]


spectrum <- fread(
  './Allele_Frequency_Spectrum2.bed',header=F,
  col.names = c('chromosome', 'start', 'end', 'value')
)
spectrum <- spectrum[order(start)]
head(spectrum)
dim(spectrum)



####################################################################################################################
####################################################################################################################
####################################################################################################################
##### LOAD ZETAS for each species


getwd()

head(filtered)
dim(filtered)


###############################################
colnames(filtered)
###############################################


# LOAD SARS-CoV-2 Results
SARS_CoV_2 <- fread('./SARS_CoV_2.bedGraph',header=F,   col.names = c('chromosome', 'start', 'end', 'value'))
SARS_CoV_2 <- SARS_CoV_2[order(start)]

SARS_CoV_2_0.05 <- fread('./SARS_CoV_2_0.05.bedGraph',header=F, col.names = c('chromosome', 'start', 'end', 'value'))
SARS_CoV_2_0.05 <- SARS_CoV_2_0.05[order(start)]
subset(SARS_CoV_2_0.05, value > 4)


track <- DataTrack( range = SARS_CoV_2, type = "p",  genome = 'wuhCor1',  name = "SARS_CoV_2",  size=10, col="black",  
                    lty.baseline= 1,baseline=0, col.baseline = "black",  ylim= c(0,10), cex=0.5)

track0.05 <- DataTrack( range = SARS_CoV_2_0.05,  type = "p",  genome = 'wuhCor1',  name = "SARS_CoV_2",  size=10, col="red",  
                        lty.baseline= 1,baseline=0, col.baseline = "black",  ylim= c(0,10), cex=1)
ot_SARS_CoV_2 <- OverlayTrack(trackList = list(track, track0.05))
####

# LOAD Bat-CoV-RatG13 Results
RatG13 <- fread('./RatG13.bedGraph',header=F, col.names = c('chromosome', 'start', 'end', 'value'))
RatG13 <- RatG13[order(start)]
RatG13_0.05 <- fread('./RatG13_0.05.bedGraph',header=F,col.names = c('chromosome', 'start', 'end', 'value'))
RatG13_0.05 <- RatG13_0.05[order(start)]
subset(RatG13_0.05, value > 4)

track <- DataTrack(range = RatG13,type = "p", genome = 'wuhCor1', name = "RatG13",size=10, col="black", 
                   lty.baseline= 1,baseline=0, col.baseline = "black", ylim= c(0,10), cex=0.5)
track0.05 <- DataTrack(range = RatG13_0.05, type = "p",genome = 'wuhCor1',  name = "RatG13",  size=10, col="red",  
                       lty.baseline= 1,baseline=0, col.baseline = "black",  ylim= c(0,10), cex=1)
ot_RatG13<- OverlayTrack(trackList = list(track, track0.05))


####

# LOAD PANGOLIN-CoV Results
getwd()

PangolinCoV_GD <- fread( './PangolinCoV_GD.bedGraph',header=F,  col.names = c('chromosome', 'start', 'end', 'value'))
PangolinCoV_GD <- PangolinCoV_GD[order(start)]

PangolinCoV_GD_0.05 <- fread('./PangolinCoV_GD_0.05.bedGraph',header=F, col.names = c('chromosome', 'start', 'end', 'value'))
PangolinCoV_GD_0.05 <- PangolinCoV_GD_0.05[order(start)]
subset(PangolinCoV_GD_0.05, value > 4)

track <- DataTrack( range = PangolinCoV_GD,type = "p",  genome = 'wuhCor1',  name = "PangolinCoV_GD",  size=10, col="black",  
                    lty.baseline= 1,baseline=0, col.baseline = "black",  ylim= c(0,10), cex=0.5)

track0.05 <- DataTrack( range = PangolinCoV_GD_0.05,  type = "p",genome = 'wuhCor1', name = "PangolinCoV_GD",  size=10, col="red",  
                        lty.baseline= 1,baseline=0, col.baseline = "black",  ylim= c(0,10), cex=1)

ot_PangolinCoV_GD <- OverlayTrack(trackList = list(track, track0.05))




PangolinCoV_P4L <- fread( './PangolinCoV_P4L.bedGraph',header=F,  col.names = c('chromosome', 'start', 'end', 'value'))
PangolinCoV_P4L <- PangolinCoV_P4L[order(start)]

PangolinCoV_P4L_0.05 <- fread('./PangolinCoV_P4L_0.05.bedGraph',header=F, col.names = c('chromosome', 'start', 'end', 'value'))
PangolinCoV_P4L_0.05 <- PangolinCoV_P4L_0.05[order(start)]
subset(PangolinCoV_P4L_0.05, value > 4)

track <- DataTrack( range = PangolinCoV_P4L,type = "p",  genome = 'wuhCor1',  name = "PangolinCoV_P4L",  size=10, col="black",  
                    lty.baseline= 1,baseline=0, col.baseline = "black",  ylim= c(0,10), cex=0.5)

track0.05 <- DataTrack( range = PangolinCoV_P4L_0.05,  type = "p",genome = 'wuhCor1', name = "PangolinCoV_P4L",  size=10, col="red",  
                        lty.baseline= 1,baseline=0, col.baseline = "black",  ylim= c(0,10), cex=1)

ot_PangolinCoV_P4L <- OverlayTrack(trackList = list(track, track0.05))


####

# LOAD SARS-CoV Results

SARS_CoV <- fread('./SARS_CoV.bedGraph',header=F,  col.names = c('chromosome', 'start', 'end', 'value'))
SARS_CoV <- SARS_CoV[order(start)]

SARS_CoV_0.05 <- fread( './SARS_CoV_0.05.bedGraph',header=F,  col.names = c('chromosome', 'start', 'end', 'value'))
SARS_CoV_0.05 <- SARS_CoV_0.05[order(start)]
subset(SARS_CoV_0.05, value > 4)

track <- DataTrack(  range = SARS_CoV,  type = "p",  genome = 'wuhCor1',  name = "SARS_CoV",  size=10, col="black",  
                     lty.baseline= 1,baseline=0, col.baseline = "black",  ylim= c(0,10), cex=0.5)

track0.05 <- DataTrack(  range = SARS_CoV_0.05,  type = "p",  genome = 'wuhCor1',  name = "SARS_CoV",  size=10, col="red",  
                         lty.baseline= 1,baseline=0, col.baseline = "black",  ylim= c(0,10), cex=1)

ot_SARS_CoV <- OverlayTrack(trackList = list(track, track0.05))


####

# LOAD Bat-CoV- Lyra11  Results

LYRa11 <- fread('./LYRa11.bedGraph',header=F,  col.names = c('chromosome', 'start', 'end', 'value'))
LYRa11 <- LYRa11[order(start)]

LYRa11_0.05 <- fread( './LYRa11_0.05.bedGraph',header=F,  col.names = c('chromosome', 'start', 'end', 'value'))
LYRa11_0.05 <- LYRa11_0.05[order(start)]

track <- DataTrack(  range = LYRa11,  type = "p",  genome = 'wuhCor1',  name = "LYRa11",  size=10, col="black",  
                     lty.baseline= 1,baseline=0, col.baseline = "black",  ylim= c(0,10), cex=0.5)

track0.05 <- DataTrack(  range = LYRa11_0.05,  type = "p",  genome = 'wuhCor1',  name = "LYRa11",  size=10, col="red",  
                         lty.baseline= 1,baseline=0, col.baseline = "black",  ylim= c(0,10), cex=1)
ot_LYRa11 <- OverlayTrack(trackList = list(track, track0.05))



###############################################
##### PHASTCONS
getwd()
delimiter1= (transform(filtered$genome_location, FOO= colsplit(filtered$genome_location, "-", names=c("start", "end"))))
delimiter2 = (transform(delimiter1$FOO.start , FOO= colsplit(delimiter1$FOO.start,  ":", names=c("a", "b"))))
phastcons <- (data.frame(delimiter2$FOO.a, delimiter2$FOO.b, delimiter1$FOO.end, (filtered$phastCons)))
write.table(phastcons, file ="phastcons.bedGraph", row.names=F, col.names=F, quote=F,sep='\t') 


filtered_0.9 <- (subset(filtered,  phastCons > 0.9 ))
delimiter1= (transform(filtered_0.9$genome_location, FOO= colsplit(filtered_0.9$genome_location, "-", names=c("start", "end"))))
delimiter2 = (transform(delimiter1$FOO.start , FOO= colsplit(delimiter1$FOO.start,  ":", names=c("a", "b"))))
ultraphastcons <- (data.frame(delimiter2$FOO.a, delimiter2$FOO.b, delimiter1$FOO.end, (filtered_0.9$phastCons)))
write.table(ultraphastcons, file ="ultraphastcons.bedGraph", row.names=F, col.names=F, quote=F,sep='\t') 


phastcons <- fread( './phastcons.bedGraph',header=F,  col.names = c('chromosome', 'start', 'end', 'value'))
phastcons <- phastcons[order(start)]

ultraphastcons <- fread( './ultraphastcons.bedGraph',header=F,  col.names = c('chromosome', 'start', 'end', 'value'))
ultraphastcons <- ultraphastcons[order(start)]

track <- DataTrack(  range = phastcons,  type = "p",  genome = 'wuhCor1',  name = "phastcons",  size=10, col="black",  
                     lty.baseline= 1,baseline=0, col.baseline = "black",  ylim= c(0,1), cex=0.5)

track0.9 <- DataTrack(  range = ultraphastcons,  type = "p",  genome = 'wuhCor1',  name = "phastcons",  size=10, col="blue",  
                        lty.baseline= 1,baseline=0.9, col.baseline = "black",  ylim= c(0,1), cex=1)

ot_phastcons <- OverlayTrack(trackList = list(track, track0.9))


##################################################################################################



unexpected <- fread('./unexpected_trees2.bed',header=F,   col.names = c('chromosome', 'start', 'end'))

unexpected <- unexpected[order(start)]

unexpected_track <- AnnotationTrack(unexpected, name = "Unexpected", stacking = "dense",collapse=TRUE, fill= "black")



SARS_CoV_2_merged <- fread('./SARS_CoV_2.merged.bed',header=F,   col.names = c('chromosome', 'start', 'end'))
SARS_CoV_2_merged <- SARS_CoV_2_merged[order(start)]
SARS_CoV_2_merged_track <- AnnotationTrack(SARS_CoV_2_merged, name = "SARS-CoV-2", stacking = "dense",collapse=TRUE, fill= "red")

RaTG13_merged <- fread('./RatG13.merged.bed',header=F,   col.names = c('chromosome', 'start', 'end'))
RaTG13_merged <- RaTG13_merged[order(start)]
RaTG13_merged_track <- AnnotationTrack(RaTG13_merged, name = "Bat-CoV-RaTG13", stacking = "dense",collapse=TRUE, fill= "red")

PangolinCoV_GD_merged <- fread('./PangolinCoV_GD.merged.bed',header=F,   col.names = c('chromosome', 'start', 'end'))
PangolinCoV_GD_merged <- PangolinCoV_GD_merged[order(start)]
PangolinCoV_GD_merged_track <- AnnotationTrack(PangolinCoV_GD_merged, name = "Pan-CoV-GD", stacking = "dense",collapse=TRUE, fill= "red")

PangolinCoV_P4L_merged <- fread('./PangolinCoV_P4L.merged.bed',header=F,   col.names = c('chromosome', 'start', 'end'))
PangolinCoV_P4L_merged <- PangolinCoV_P4L_merged[order(start)]
PangolinCoV_P4L_merged_track <- AnnotationTrack(PangolinCoV_P4L_merged, name = "Pan-CoV-P4L", stacking = "dense",collapse=TRUE, fill= "red")

SARS_CoV_merged <- fread('./SARS_CoV.merged.bed',header=F,   col.names = c('chromosome', 'start', 'end'))
SARS_CoV_merged <- SARS_CoV_merged[order(start)]
SARS_CoV_merged_track <- AnnotationTrack(SARS_CoV_merged, name = "SARS-CoV", stacking = "dense",collapse=TRUE, fill= "red")

LYRa11_merged <- fread('./LYRa11.merged.bed',header=F,   col.names = c('chromosome', 'start', 'end'))
LYRa11_merged <- LYRa11_merged[order(start)]
LYRa11_merged_track <- AnnotationTrack(LYRa11_merged, name = "Bat-CoV-LYRa11", stacking = "dense",collapse=TRUE, fill= "red")


##############################################





thechr <- "chr"
st<- 1
en<- 29903
gen<-"wuhCor1"



gtrack <- GenomeAxisTrack(col="black")


################################################################

covid19_mature_products_2[1,]

aTrack3 <- AnnotationTrack(start = c(as.numeric(covid19_mature_products_2[1:32,2])),
                           end =   c(as.numeric(covid19_mature_products_2[1:32,3])),
                           chromosome = "chr", #strand = c("+","*", "-"),
                           
                           id =c(covid19_mature_products_2[1:32,4]), 
                           just.group = "left",
                           #strand = "*",
                           
                           genome = "wuhCor1", name = "mature")

covid19_mature_products_2

feature(aTrack3)
## [1] "unknow" "unknown" "unknown" "unknown" "unknown" "unknown"
feature(aTrack3) <-  as.character(covid19_mature_products_2[,4])


phastcons_track <- DataTrack(
  range = phastcons,
  type = "p",
  genome = 'wuhCor1',
  name = "PhastCons",
  size=5, col="black", cex=0.5,
  lty.baseline= 0.5,baseline=c(0,0.9), col.baseline = c("black", "red"),
  ylim= c(0,1.1)
)

substitutions_track <- DataTrack(
  range = substitutions,
  type = "histogram",    # c("l","p"),
  genome = 'wuhCor1',
  name = "AAF",
  size=5, col="black",
  lty.baseline= 1, baseline=0, col.baseline = "black",  ylim= c(0,1.01)
)


substitutions_track <- DataTrack(
  range = substitutions3,
  type = "histogram",    # c("l","p"),
  genome = 'wuhCor1',
  name = "AAF",
  size=5, col="black",
  lty.baseline= 1, baseline=0, col.baseline = "black",  ylim= c(0,1.01)
)

spectrum_track <- DataTrack(
  range = spectrum,
  type = c("l","p"),
  genome = 'wuhCor1',
  name = "AlleleSpectrum",
  size=5, col="black",
  lty.baseline= 1, baseline=0, col.baseline = "black",  ylim= c(0,0.01)
)

###########################################################################################################

subset(SARS_CoV_2_0.05, value > 2)
subset(SARS_CoV_2_0.05)$start
subset(SARS_CoV_2_0.05)$end


subset()$start
subset(SARS_CoV_2_0.05)$end

subset(SARS_CoV_0.05)$start
subset(SARS_CoV_0.05)$end

SARS_CoV_2_0.05
SARS_CoV_0.05
subset(SARS_CoV_2_0.05, start > 21598 )
#subset(SARS_CoV_0.05, start > 21598 & end < 25381)$end

subset(SARS_CoV_0.05, start > 21598 & end < 26000)
#subset(SARS_CoV_0.05, start > 21598 & end < 25381)$end

ht <- HighlightTrack(trackList=list(aTrack3), 
                     start=c(9601, 21001, 21601, 22501, 22651, 22801, 22951, 23551, 23701, 24901), 
                     end = c(9900, 21300, 21900, 22800, 22950 ,23100, 23250, 23850, 24000, 25200), chromosome = "chr")
#ht_sars <- HighlightTrack(trackList=list(aTrack3), 
#                     start=c(20851,21001,21301,21451,21601,21751,21901,22051,22201,22351,22501,23251,23401,23551,23701,23851,24001,25651,25801,25951), 
#                     end = c(21150,21300,21600,21750,21900,22050,22200,22350,22500,22650,22800,23550,23700,23850,24000,24150,24300,25950,26100,26250), chromosome = "chr")




# FIGURE 1 
plotTracks(list( ot_SARS_CoV_2, ot_RatG13, ot_PangolinCoV_GD, ot_PangolinCoV_P4L,  ot_LYRa11, ot_SARS_CoV, ht,   gtrack) , #featureAnnotation = "feature", 
           groupAnnotation = "feature",
           fontcolor.feature = 1,
           col.border.title='white',
           #background.panel='white',
           background.title = 'white', 
           col.axis='black',lwd=1, 
           just.group = "left",
           col.title="black", 
           frame=FALSE, 
           grid=FALSE, 
           Highlights = "darkred",
           cex.feature = 0.7)



#FIGURE X (Overlap of selection with recombination)

plotTracks(list(  SARS_CoV_2_merged_track,RaTG13_merged_track,PangolinCoV_GD_merged_track,PangolinCoV_P4L_merged_track, LYRa11_merged_track,SARS_CoV_merged_track,unexpected_track,  aTrack3, gtrack) , #featureAnnotation = "feature", 
           #groupAnnotation = "feature",
           fontcolor.feature = 1,
           col.border.title='white',
           #background.panel='white',
           background.title = 'white', 
           col.axis='black',lwd=1, 
           just.group = "left",
           col.title="black", 
           frame=FALSE, 
           grid=FALSE, 
           Highlights = "darkred",
           cex.feature = 0.7)



####################################################################################################################

plotTracks(list(reference_track))


####################################################################################################################
subset(SARS_CoV_2, start > 27500 & end < 28800)
subset(SARS_CoV_2_0.05)$start
subset(SARS_CoV_2_0.05)$end

phastcons

subset(phastcons, value > 0.9)$start
subset(phastcons, value > 0.9)$end

substitutions3


ht2 <- HighlightTrack(trackList=list(ot_phastcons, substitutions_track, aTrack3), 
                     start=c(1,151,10651,11401,12151,12901,13051,13201,13351,13501,13651,14251,14401,14551,14851,15301,15451,15601,15751,15901,16051,
                             16201,16651,16801,26101,26251,26401,28201,28351,28501,28651,28951,29101,29251,29401,29551), 
                     end = c(300  ,450,10950,11700,12450,13200,13350,13500,13650,13800,13950,14550,14700,14850,15150,15600,15750,15900,16050,16200,16350,
                             16500,16950,17100,26400,26550,26700,28500,28650,28800,28950,29250,29400,29550,29700,29850), chromosome = "chr")


### FIGURE 2


plotTracks(list(ot_SARS_CoV_2, ot_phastcons, substitutions_track,spectrum_track, aTrack3,  gtrack) , #featureAnnotation = "feature", 
           groupAnnotation = "feature", fontcolor.feature = 1, col.border.title='white', 
           background.title = 'white', col.axis='black',lwd=1, just.group = "left",
           col.title="black", frame=FALSE, grid=FALSE, Highlights = "darkred",
           cex.feature = 0.7)








####################################################################################################################
plotTracks(list(ot_SARS_CoV_2, reference_track, aTrack3,  gtrack) , #featureAnnotation = "feature", 
           groupAnnotation = "feature", fontcolor.feature = 1, col.border.title='white', background.panel='white',
           background.title = 'white', col.axis='black',lwd=1, just.group = "left",
           col.title="black", frame=FALSE, grid=FALSE, Highlights = "darkred",
           cex.feature = 0.7)

####################################################################################################################

#############################################################################################
head(covid19_data_ref_melt_cast)
dim(covid19_data_ref_melt_cast)
library(MASS)
p = 0.05
# 2-dimentional kernel density estimation for the neutral data
#dens <- kde2d(log10(covid19_data_ref_melt_cast$zeta.wuhCor1),log10(covid19_data_ref_melt_cast$zeta.SARS_CoV), n=1000, lims = c(-2, 3, -2, 3)) 
dens <- kde2d(log10(covid19_data_ref_melt_cast$zeta.SARS_CoV_2),log10(covid19_data_ref_melt_cast$zeta.SARS_CoV), n=1000, lims = c(-2, 3, -2, 3)) 


myPal<- colorRampPalette(c("gray100", "gray50", "gray25", "gray1", "black"))


#filtered <- subset(fibroblast.selection.data)



#filtered_1 <- (subset(filtered,  pval.SARS_CoV_2 < p ))
#filtered_2 <- (subset(filtered,  pval.SARS_CoV_2 < p ))
head(filtered)
head(filtered1)
head(filtered2)
head(filtered3)
head(filtered4)



dim(filtered)

dim(filtered1)
dim(filtered2)
dim(filtered3)
dim(filtered4)

#head(filtered3, n=78)

dev.off()
library(calibrate)
dim(filtered)
dim(filtered2)
dim(filtered3)
dim(filtered4)


library(adegenet)


plot(log10(filtered$zeta.SARS_CoV_2),log10(filtered$zeta.SARS_CoV),
     xaxt = 'n', yaxt = 'n',type='o', col="white", pch=20, 
     xlim=log10(c(0.1, 10)), ylim=log10(c(0.1, 10)), 
     xlab = expression(paste(zeta," Foreground SARS-CoV-2")), 
     ylab = expression(paste(zeta," Foreground SARS-CoV")))
axis(1, at = c(-1, 0, 1, 2), labels = c(0.1, 1, 10, 100))
axis(2, at = c(-1, 0, 1, 2), labels = c(0.1, 1, 10, 100))
image(dens, col=transp(myPal(5000),0.8), add=TRUE, useRaster=TRUE)
abline(v= log10(1), h=log10(1), lty=3)
#title("Local Accelerated Regions (P < 0.05)")
points(log10(filtered2$zeta.SARS_CoV_2),log10(filtered2$zeta.SARS_CoV), col="black", pch=19, cex =.8) # selection in both
points(log10(filtered3$zeta.SARS_CoV_2),log10(filtered3$zeta.SARS_CoV), col="purple", pch=5,  cex =.8)  # selection in humans
points(log10(filtered4$zeta.SARS_CoV_2),log10(filtered4$zeta.SARS_CoV), col="blue", pch=3,  cex =.8)  # selection in chimps

textxy(log10(filtered2$zeta.SARS_CoV_2),log10(filtered2$zeta.SARS_CoV), labs = filtered2$genome_location,cex =0.8, col="black")
textxy(log10(filtered3$zeta.SARS_CoV_2),log10(filtered3$zeta.SARS_CoV), labs = filtered3$genome_location,cex =0.8, col="Purple")
textxy(log10(filtered4$zeta.SARS_CoV_2),log10(filtered4$zeta.SARS_CoV), labs = filtered4$genome_location,cex =0.8, col="blue")

#points(log10(neutral$RatioPhyloFit.human),log10(neutral$RatioPhyloFit.chimp), col="black", pch=".")
#legend("bottomright", inset=.005,  c("Human","Chimpanzee", "Chimpanzee and Human"), pch=c(5, 3, 19), col=c("purple", "blue", "black"), horiz=FALSE)
legend("topleft", inset=.005,  c("SARS-CoV-2 & SARS-CoV", "SARS-CoV-2", "SARS-CoV" ), pch=c(19, 5, 3), col=c("black", "Purple", "blue"), horiz=FALSE , bty = "n")

filtered1[,1]

#################################################################################################




save( substitutions3, spectrum, covid19_data, covid19_mature_products, covid19_mature_products_2, covid19_data_ref, covid19_data_ref2, 
      ot_SARS_CoV_2, ot_RatG13, ot_PangolinCoV_GD, ot_PangolinCoV_P4L,  ot_LYRa11, ot_SARS_CoV, ht,   gtrack,
      SARS_CoV_2_merged_track,RaTG13_merged_track,PangolinCoV_GD_merged_track,PangolinCoV_P4L_merged_track, LYRa11_merged_track,SARS_CoV_merged_track,unexpected_track,
      ot_phastcons, substitutions_track,spectrum_track, reference_track,spectrum2,padj.LYRa11, padj.Pa_CoV_Guangdong, padj.Pa_CoV_Guangxi_P4L, padj.RatG13, padj.SARS_CoV, padj.SARS_CoV_2,
      file="Data_sars_cov_2_evolution.RData")

getwd()

covid19_mature_products
spectrum2 <- fread(
  './Allele_Frequency_Spectrum3.bed',header=F,
  col.names = c('chromosome', 'start', 'end', 'value')
)

#### FISHER'S EXACT TESTS
## These tests are to evaluate what part of the genome of SARS-CoV-2 is more likely to have exceess of polymorphisms


25381 - 20658
8554 - 3719  

4000 + (25381 - 20658 )


#### SPIKE vs NSP3
e = sum(subset(spectrum2, start > 20658 & end < 25381  )$value)
f = sum(spectrum2$value)  - sum(subset(spectrum2, start > 20658 & end < 25381  )$value)
g = sum(subset(spectrum2, start > 3719 & end < 8554  )$value)  
h = sum(spectrum2$value)  - sum(subset(spectrum2, start > 3719 & end < 8554  )$value)
print(matrix(c(e, f, g, h),nrow = 2, dimnames = list(c("Inside", "Outside"), c("Spike", "Nsp3"))))
fisher.test(matrix(c(e, f, g, h),nrow = 2, dimnames = list(c("Inside", "Outside"), c("Spike", "Nsp3"))), alternative = "two.sided")


### SPIKE vs NSP2
e = sum(subset(spectrum2, start > 20658 & end < 25381  )$value)
f = sum(spectrum2$value)  - sum(subset(spectrum2, start > 20658 & end < 25381  )$value)
g = sum(subset(spectrum2, start > 800 & end <  5800  )$value)  
h = sum(spectrum2$value)  - sum(subset(spectrum2, start > 800 & end <  5800  )$value)
print(matrix(c(e, f, g, h),nrow = 2, dimnames = list(c("Inside", "Outside"), c("Spike", "Nsp2"))))
fisher.test(matrix(c(e, f, g, h),nrow = 2, dimnames = list(c("Inside", "Outside"), c("Spike", "Nsp2"))), alternative = "two.sided")

#### SPIKE vs 3UTR (SIGNIFICANT   ====>>>   p-value = 0.00965)
e = sum(subset(spectrum2, start > 20658 & end < 25381  )$value)
f = sum(spectrum2$value)  - sum(subset(spectrum2, start > 20658 & end < 25381  )$value)
g = sum(subset(spectrum2, start > 25903 & end < 29903  )$value)  
h = sum(spectrum2$value)  - sum(subset(spectrum2, start > 25903 & end < 29903  )$value)
print(matrix(c(e, f, g, h),nrow = 2, dimnames = list(c("Inside", "Outside"), c("Spike", "3UTR"))))
fisher.test(matrix(c(e, f, g, h),nrow = 2, dimnames = list(c("Inside", "Outside"), c("Spike", "3UTR"))), alternative = "two.sided")

#### SPIKE vs 5UTR (SIGNIFICANT   ====>>>   p-value = 0.01763)
e = sum(subset(spectrum2, start > 20658 & end < 25381  )$value)
f = sum(spectrum2$value)  - sum(subset(spectrum2, start > 20658 & end < 25381  )$value)
g = sum(subset(spectrum2, start > 0 & end < 5500  )$value)  
h = sum(spectrum2$value)  - sum(subset(spectrum2, start > 0 & end < 5500  )$value)
print(matrix(c(e, f, g, h),nrow = 2, dimnames = list(c("Inside", "Outside"), c("Spike", "5UTR"))))
fisher.test(matrix(c(e, f, g, h),nrow = 2, dimnames = list(c("Inside", "Outside"), c("Spike", "5UTR"))), alternative = "two.sided")




### SPIKE vs Hel-Exon
e = sum(subset(spectrum2, start > 20658 & end < 25381  )$value)
f = sum(spectrum2$value)  - sum(subset(spectrum2, start > 20658 & end < 25381  )$value)
g = sum(subset(spectrum2, start > 16236 & end < 20658  )$value)  
h = sum(spectrum2$value)  - sum(subset(spectrum2, start > 16236 & end < 20658  )$value)
print(matrix(c(e, f, g, h),nrow = 2, dimnames = list(c("Inside", "Outside"), c("Spike", "Hel-Exon"))))
fisher.test(matrix(c(e, f, g, h),nrow = 2, dimnames = list(c("Inside", "Outside"), c("Spike", "Hel-Exon"))), alternative = "two.sided")





a = 24
b = 651 - 24
c = 60
d = 449 - 60
print(matrix(c(a, b, c, d),nrow = 2, 
             dimnames = list( c("RB Woodpecker", "Non RBWP"), 
                              c("Food 1", "Food 2"))))
fisher.test(matrix(c(a, b, c, d),nrow = 2, 
                   dimnames =  list( c("RB Woodpecker", "Non RBWP"), 
                                     c("Food 1", "Food 2"))), 
            alternative = "two.sided")






